
#include "Arduino.h"
#include "QuickStats.h"
#include <math.h>

QuickStats::QuickStats(){}
QuickStats::~QuickStats(){}

float QuickStats::average(float samples[],int m)
{
  float total1=0.0;
  for(int i=0;i<m;i++){
    total1=total1+samples[i];
  }
  return total1/(float)m;
}

float QuickStats::g_average(float samples[],int m)
{
  float total1=0.0;
  for(int i=0;i<m;i++){
    total1=total1+log(samples[i]);
  }
  return exp(total1/(float)m);
}

float QuickStats::minimum(float samples[],int m)
{
  float sorted[m];   
  for(int i=0;i<m;i++){
    sorted[i]=samples[i];
  }
  bubbleSort(sorted,m); 
  return(sorted[0]); 
}

float QuickStats::maximum(float samples[],int m)
{
  float sorted[m];   
  for(int i=0;i<m;i++){
    sorted[i]=samples[i];
  }
  bubbleSort(sorted,m);  
  return(sorted[m-1]); 
}

float QuickStats::stdev(float samples[],int m)
{
  float avg=0.0;
  float total2=0.0;
  avg=average(samples,m);
  for(int i=0;i<m;i++){
    total2 = total2 + pow(samples[i] - avg,2);
  }
  return sqrt(total2/((float)m-1.0));
}

float QuickStats::stderror(float samples[],int m)
{
  float temp1=0.0;
  temp1=stdev(samples,m);
  return (temp1/sqrt((float)m));
}

float QuickStats::CV(float samples[],int m)  
{
  float avg=0.0;
  float sd=0.0;
  avg=average(samples,m);
  sd=stdev(samples,m);
  return 100.0*sd/avg;
}

void QuickStats::bubbleSort(float A[],int len)
{
  unsigned long newn;
  unsigned long n=len;
  float temp=0.0;
  do {
    newn=1;
    for(int p=1;p<len;p++){
      if(A[p-1]>A[p]){
        temp=A[p];           
        A[p]=A[p-1];
        A[p-1]=temp;
        newn=p;
      } //end if
    } //end for
    n=newn;
  } while(n>1);
}

float QuickStats::fabs(float sample) 
{ 
  if(sample<0.f){
    return -sample;
  }else{
    return sample;
  }
}

float QuickStats::median(float samples[],int m) 
{
  /
  float sorted[m];   
  float temp=0.0;     
  
  }
  for(int i=0;i<m;i++){
    sorted[i]=samples[i];
  }
  bubbleSort(sorted,m); 


  if (bitRead(m,0)==1) {  
    return sorted[m/2]; 
  } else {    
    return (sorted[(m/2)-1]+sorted[m/2])/2; 
  }
}

float QuickStats::mode(float samples[],int m,float epsilon) 

{
  
  float sorted[m];   
  float temp=0;      
  float unique[m];  
  int uniquect[m]; 
  
  for(int i=0;i<m;i++){
    sorted[i]=samples[i];
  }
  bubbleSort(sorted,m);  


  unique[0]=sorted[0];
  uniquect[0]=1;
  int p=0; 
  int maxp=0;
  int maxidx=0;
  for(int i=1;i<m;i++){ 
    if(fabs(sorted[i]-sorted[p])<epsilon){
      uniquect[p]++;  
      if(uniquect[p]>maxp){
        maxp=uniquect[p];
        maxidx=p;      
      }
    } else {
      p++;
      unique[p]=sorted[i];
      uniquect[p]=1;
    }
  }
  
  if (maxp>1) {    
    return unique[maxidx]; 
  } else {
    return 0.0; 
  }
}

float QuickStats::slope(float x[],float samples[],int m) 
{
  float xavg=average(x,m);
  float yavg=average(samples,m);
  float numerator = 0.0;
  float denominator = 0.0;
  for(int i=0;i<m;i++){
    if(x[i]-xavg!=0.0){ 
      numerator = numerator + (x[i]-xavg)*(samples[i]-yavg);
      denominator = denominator + ((x[i]-xavg)*(x[i]-xavg));
    }
  }
  return numerator/denominator;  
}

float QuickStats::intercept(float x[],float samples[],int m)  
{
  float xavg=average(x,m);
  float yavg=average(samples,m);
  float beta=slope(x,samples,m);
  return yavg-(beta*xavg);
}

void QuickStats::filternan(float samples[],int &m)  
{
  int duds=0; 
  int nums=0; 
  float filtered[m];
  for(int i=0;i<m;i++){
    if(isnan(samples[i])||isinf(samples[i])){
      duds++; 
    }else{
      filtered[nums]=samples[i];
      nums++;  
    }
  }
  for(int i=0;i<nums;i++){
    samples[i]=filtered[i]; 
  }
  m=nums; 
}

void QuickStats::f_round(float samples[], int m, int p)  
{
  float precision=pow(10.0,p);
  for(int i=0;i<m;i++){
    samples[i]=round(samples[i]*precision)/precision;
  }
}