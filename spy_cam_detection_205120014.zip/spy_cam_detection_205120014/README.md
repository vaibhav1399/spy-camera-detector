# Spy cam detection: Mobile Minder


## What it does
We have built an IoT device to locate spy cams using a variety of distinct methods. Statistical analyses run on our sound detector can detect audio anomalies suggesting the click of a motion-activated camera. For added robustness, we pair a photoresistor with an LED to sense the telltale glint of a camera lens. We are looking into incorporating EMF and RF detection mechanisms as well, which are underutilized in pre-existing detectors currently on the markets but represent a promising additional source of corroboration. The outputs of these sensors connect to a real-time graph through the Arduino Serial Plotter which can be monitored and used to trigger an alarm.

## How we built it
Our device is based on an Arduino Uno. We also implemented sound and light Grove Seeed sensors. Our code was written in C++ for Arduino supported by statistical packages.





